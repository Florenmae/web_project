

<style type="text/css">
	<?php 
		include 'style.css';
	?>
</style>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-------box icon links---->
	<!----<link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css">---->

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>

</head>

<body>
		<footer>
			<div class="inner-footer">
				<div class="card">
					<h3>About us</h3>
					<ul>
						<li>About us</li>
						<li>Our differences</li>
						<li>policies</li>
						<li>About us</li>
						<li>About us</li>
					</ul>
				</div>

				<div class="card">
					<h3>Services</h3>
					<ul>
						<li>orders</li>
						<li>help</li>
						<li>shipping</li>
						<li>policies</li>
						<li>About us</li>
					</ul>
				</div>

				<div class="card">
					<h3>Policies</h3>
					<ul>
						<li>About us</li>
						<li>Our differences</li>
						<li>policies</li>
						<li>About us</li>
						<li>About us</li>
					</ul>
				</div>

				<div class="card">
					<h3>Updates</h3>
					<p>Sign up for updates from us!</p>
					<div class="input-field">
						<input type="submit" name="" placeholder="email address...">
					</div>
					<div class="social-links">
						<i class="bi bi-facebook"></i>
						<i class="bi bi-messenger"></i>
						<i class="bi bi-instagram"></i>
						<i class="bi bi-twitter"></i>
					</div>
				</div>
			</div>
			<div class="bottom-footer">
				<p>all right reserved - power puff girls</p>
			</div>
		</footer>



	<script type="text/javascript" src="script2.js"></script>
</body>
</html>